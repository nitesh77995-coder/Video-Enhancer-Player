package com.nitesh.videoenhancer

import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.nitesh.videoenhancer.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var player: ExoPlayer? = null

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        contentResolver.takePersistableUriPermission(
            uri,
            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        play(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        player = ExoPlayer.Builder(this).build().also {
            binding.playerView.player = it
        }

        binding.openButton.setOnClickListener {
            picker.launch(arrayOf("video/*"))
        }

        binding.enhanceButton.setOnClickListener {
            binding.enhancePanel.visibility =
                if (binding.enhancePanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        binding.sharpenSwitch.setOnCheckedChangeListener { _, checked ->
            binding.fpsInfo.text = if (checked)
                "Sharpen: ON • GPU-safe preview"
            else
                "Sharpen: OFF"
        }

        binding.hdrSwitch.setOnCheckedChangeListener { _, checked ->
            if (checked) binding.fpsInfo.text = "Dynamic contrast: ON"
        }
    }

    private fun play(uri: Uri) {
        player?.setMediaItem(MediaItem.fromUri(uri))
        player?.prepare()
        player?.play()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
