# Video Enhancer Player

Android video player project.

## Current features
- Local video picker
- Media3/ExoPlayer playback
- Landscape player UI
- Enhancement panel UI
- Sharpen and dynamic-contrast controls (preview controls)

## Important
This starter build does **not** claim true AI upscaling or AI frame interpolation yet. Those require a real GPU processing pipeline/model. The project is structured so those processing features can be added next.

## Build
Open the project in Android Studio or build it with Gradle/Android CI.
