# Video Enhancer Player

A simple Android video player starter project using AndroidX Media3/ExoPlayer.

Included:
- Local video picker
- Hardware-accelerated Media3 playback when supported by the device
- Playback speed from 0.5x to 2.0x
- Fit/crop scaling modes
- GitHub Actions workflow for building a debug APK

Note: this starter version does **not** perform true AI upscaling or AI frame interpolation. Those features require a more advanced processing pipeline and device/GPU support.
