package com.nitesh.videoenhancer;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.C;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends AppCompatActivity {
    private ExoPlayer player;
    private PlayerView playerView;
    private float speed = 1.0f;
    private boolean crop = false;

    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> openPicker());

    private final ActivityResultLauncher<Intent> pickerLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) {
                        try {
                            getContentResolver().takePersistableUriPermission(
                                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } catch (Exception ignored) {}
                        play(uri);
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playerView = findViewById(R.id.playerView);
        Button open = findViewById(R.id.openButton);
        Button speedButton = findViewById(R.id.speedButton);
        Button upscaleButton = findViewById(R.id.upscaleButton);

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);

        // Ask Android to use the best available video scaling path.
        player.setVideoScalingMode(C.VIDEO_SCALING_MODE_SCALE_TO_FIT);

        open.setOnClickListener(v -> requestVideoAccess());

        speedButton.setOnClickListener(v -> {
            speed += 0.25f;
            if (speed > 2.0f) speed = 0.5f;
            player.setPlaybackParameters(new PlaybackParameters(speed));
            speedButton.setText(String.format("Speed %.2fx", speed));
        });

        upscaleButton.setOnClickListener(v -> {
            crop = !crop;
            player.setVideoScalingMode(
                    crop ? C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                          : C.VIDEO_SCALING_MODE_SCALE_TO_FIT);
            upscaleButton.setText(crop ? "Upscale: Crop" : "Upscale: Fit");
        });
    }

    private void requestVideoAccess() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                    != PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(Manifest.permission.READ_MEDIA_VIDEO);
            } else {
                openPicker();
            }
        } else {
            openPicker();
        }
    }

    private void openPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        pickerLauncher.launch(intent);
    }

    private void play(Uri uri) {
        player.setMediaItem(MediaItem.fromUri(uri));
        player.prepare();
        player.play();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        if (player != null) player.release();
        super.onDestroy();
    }
}
