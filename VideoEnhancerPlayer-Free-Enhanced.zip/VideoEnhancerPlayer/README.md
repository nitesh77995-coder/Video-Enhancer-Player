# Free Video Enhancer Player

A free Android video player project built with Media3/ExoPlayer.

## Included in this version
- Local video picker and Media3 playback
- High-resolution/HDR-capable playback when supported by the device and source
- Playback speed: 0.5x to 2x
- Picture-in-picture
- Subtitle track toggle
- Brightness, contrast and saturation controls
- Enhancement menu for AI-upscaling and motion-interpolation modules
- Sharpening option and 60-FPS/motion-smoothing architecture

## Important limitation
The UI and playback architecture are ready for GPU/NPU enhancement modules, but this project does **not** claim to perform true AI super-resolution or motion-compensated frame interpolation yet. Those require an actual neural-network model/runtime (for example an on-device GPU/NPU pipeline), which is substantially heavier than ordinary ExoPlayer playback.

## Build from a phone
Upload this project to GitHub and use GitHub Codespaces or another Android cloud build environment. Open the project in Android Studio/cloud IDE and run the Gradle Android build.

Application ID: `com.example.videoenhancer`
