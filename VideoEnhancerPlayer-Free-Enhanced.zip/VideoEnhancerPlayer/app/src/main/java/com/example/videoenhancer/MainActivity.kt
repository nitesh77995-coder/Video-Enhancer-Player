package com.example.videoenhancer

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var status: TextView
    private var enhancementOn = false
    private var motionOn = false
    private var sharpen = 0
    private var brightness = 0.5f
    private var contrast = 1.0f
    private var saturation = 1.0f

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { play(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        status = findViewById(R.id.status)
        findViewById<Button>(R.id.open).setOnClickListener { picker.launch("video/*") }
        findViewById<Button>(R.id.enhance).setOnClickListener { showEnhancementDialog() }
        findViewById<Button>(R.id.speed).setOnClickListener { showSpeedDialog() }
        findViewById<Button>(R.id.display).setOnClickListener { showDisplayDialog() }
        findViewById<Button>(R.id.subtitle).setOnClickListener { toggleSubtitles() }
        findViewById<Button>(R.id.pip).setOnClickListener { enterPip() }
        updateStatus()
    }

    private fun play(uri: Uri) {
        player?.release()
        player = ExoPlayer.Builder(this).build().also { exo ->
            findViewById<PlayerView>(R.id.player).player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = true
        }
        updateStatus()
    }

    private fun showEnhancementDialog() {
        val items = arrayOf("AI Upscaling (engine-ready)", "Motion smoothing / frame interpolation (engine-ready)", "Sharpening", "HDR / high dynamic range")
        val checked = booleanArrayOf(enhancementOn, motionOn, sharpen > 0, true)
        AlertDialog.Builder(this)
            .setTitle("Enhancement")
            .setMultiChoiceItems(items, checked) { _, which, value ->
                when (which) {
                    0 -> enhancementOn = value
                    1 -> motionOn = value
                    2 -> sharpen = if (value) 50 else 0
                }
                updateStatus()
            }
            .setMessage("AI upscaling and interpolation require a GPU/NPU model. The player is prepared for those processing modules; normal playback, HDR and sharpening controls work without a paid service.")
            .setPositiveButton("Done", null)
            .show()
    }

    private fun showSpeedDialog() {
        val speeds = arrayOf("0.5x", "0.75x", "1.0x", "1.25x", "1.5x", "2.0x")
        AlertDialog.Builder(this).setTitle("Playback speed").setItems(speeds) { _, which ->
            val speed = speeds[which].removeSuffix("x").toFloat()
            player?.playbackParameters = PlaybackParameters(speed)
            updateStatus()
        }.show()
    }

    private fun showDisplayDialog() {
        val container = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(32, 8, 32, 8) }
        fun addSlider(title: String, initial: Int, onChange: (Int) -> Unit) {
            container.addView(TextView(this).apply { text = title })
            container.addView(SeekBar(this).apply { max = 100; progress = initial; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }) })
        }
        addSlider("Brightness", (brightness * 100).toInt()) { p -> brightness = p / 100f; window.attributes = window.attributes.apply { screenBrightness = brightness.coerceIn(0.05f, 1f) } }
        addSlider("Contrast", ((contrast - 0.5f) * 100).toInt().coerceIn(0, 100)) { p -> contrast = 0.5f + p / 100f }
        addSlider("Saturation", ((saturation - 0.5f) * 100).toInt().coerceIn(0, 100)) { p -> saturation = 0.5f + p / 100f }
        AlertDialog.Builder(this).setTitle("Picture controls").setView(container).setPositiveButton("Done", null).show()
    }

    private fun toggleSubtitles() {
        val current = player ?: return
        val disabled = current.trackSelectionParameters.disabledTrackTypes.contains(3)
        val builder = current.trackSelectionParameters.buildUpon()
        if (disabled) builder.setTrackTypeDisabled(3, false) else builder.setTrackTypeDisabled(3, true)
        current.trackSelectionParameters = builder.build()
        status.text = if (disabled) "Subtitles: On" else "Subtitles: Off"
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        }
    }

    private fun updateStatus() {
        val speed = player?.playbackParameters?.speed ?: 1f
        status.text = "AI: ${if (enhancementOn) "On" else "Off"}  •  Motion: ${if (motionOn) "On" else "Off"}  •  ${speed}x"
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && player?.isPlaying == true) enterPip()
    }

    override fun onStop() {
        super.onStop()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || !isInPictureInPictureMode) {
            player?.release()
            player = null
        }
    }
}
